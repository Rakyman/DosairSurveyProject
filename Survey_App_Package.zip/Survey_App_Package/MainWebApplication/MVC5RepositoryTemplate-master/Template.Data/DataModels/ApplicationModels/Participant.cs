﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Template.Data.DataModels.ApplicationModels
{
    public class Participant
    {
        [Key]
        public string Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string CellNumber { get; set; }
        public string EmailAddress { get; set; }

        public virtual ICollection<Survey> Surveys { get; set; } 
    }
}
