﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Template.Data.DataModels.ApplicationModels
{
    public class Survey
    {
        [Key]
        public int Id { get; set; }

        [ForeignKey("Question")]
        public int QuestionId { get; set; }

        [ForeignKey("Participant")]
        public string ParticipantId { get; set; }

        public string SelectedOption { get; set; }
        public DateTime Date { get; set; }

        public virtual Question Question { get; set; }
        public virtual Participant Participant { get; set; }
    }
}
