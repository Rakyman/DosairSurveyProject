﻿using Microsoft.AspNet.Identity.EntityFramework;

namespace Template.Data.DataModels.AccountModels
{
    public class ApplicationUser:IdentityUser
    {
        public string FullName { get; set; }
    }
}