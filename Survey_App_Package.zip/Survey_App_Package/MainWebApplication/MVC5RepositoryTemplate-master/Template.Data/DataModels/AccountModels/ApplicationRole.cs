﻿using Microsoft.AspNet.Identity.EntityFramework;

namespace Template.Data.DataModels.AccountModels
{
    public class ApplicationRole : IdentityRole
    {
        public ApplicationRole()
        {

        }

        public ApplicationRole(string roleName)
            : base(roleName)
        {
        }
    }

}
