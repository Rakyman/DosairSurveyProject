﻿using System.Data.Entity;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using Template.Data.DataModels.AccountModels;

namespace Template.Data.Connection
{
    public class DbInitialize<T> : DropCreateDatabaseIfModelChanges<IdentityDbContext>
        {
            protected override void Seed(IdentityDbContext context)
            {
                var userManager = new UserManager<ApplicationUser>(new 
                                                UserStore<ApplicationUser>(context)); 

                var roleManager = new RoleManager<ApplicationRole>(new 
                                          RoleStore<ApplicationRole>(context));

                const string adminrole = "AppAdmin";
                const string username="AppAdmin";
                const string password = "password";

                if (!roleManager.RoleExists(adminrole))
                {
                    roleManager.Create(new ApplicationRole(adminrole));
                }

                var user = new ApplicationUser {UserName = username};
                var adminresult = userManager.Create(user, password);

                if (adminresult.Succeeded)
                {
                    var result = userManager.AddToRole(user.Id, adminrole);
                }
                base.Seed(context);
            }
        }
    }

