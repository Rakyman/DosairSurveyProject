﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Template.BusinessLogic.GeneralLogic
{
    public class FeedBackMessages
    {
        public string LoginCredentials(string email,string password,string firstname)
        {
            var message = "Hi " + firstname + ",your survey Login credentials are as follows: Username :" + email +
                           " Password:" + password + "<br/> Follow the following link to participate in the survey http://localhost:55624/ Thank You";

            return message;
        }
    }
}
