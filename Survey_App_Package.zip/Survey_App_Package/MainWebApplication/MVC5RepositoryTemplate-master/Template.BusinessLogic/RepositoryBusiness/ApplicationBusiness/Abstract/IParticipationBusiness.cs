﻿using System.Collections.Generic;
using Template.Model.ViewModels.ApplicationViewModel;

namespace Template.BusinessLogic.RepositoryBusiness.ApplicationBusiness.Abstract
{
    public interface IParticipationBusiness
    {
        void Insert(ParticipationViewModel model);
        void Update(ParticipationViewModel model);
        ParticipationViewModel GetById(string id);
        List<ParticipationViewModel> GetAll();
    }
}
