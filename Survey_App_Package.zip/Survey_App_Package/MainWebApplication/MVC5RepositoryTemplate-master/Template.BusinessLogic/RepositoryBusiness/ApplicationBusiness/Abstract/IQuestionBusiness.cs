﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Template.Model.ViewModels.ApplicationViewModel;

namespace Template.BusinessLogic.RepositoryBusiness.ApplicationBusiness.Abstract
{
   public interface IQuestionBusiness
   {
       void Insert(QuestionViewModel model);
       void Update(QuestionViewModel model);
       QuestionViewModel GetById(int id);
       List<QuestionViewModel> GetAll();
   }
}
