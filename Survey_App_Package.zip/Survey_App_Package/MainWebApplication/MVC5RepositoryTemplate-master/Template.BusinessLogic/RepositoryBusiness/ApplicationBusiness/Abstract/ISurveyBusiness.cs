﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Template.Model.ViewModels.ApplicationViewModel;

namespace Template.BusinessLogic.RepositoryBusiness.ApplicationBusiness.Abstract
{
    public interface ISurveyBusiness
    {
        void Insert(SurveyViewModel model);
        void Update(SurveyViewModel model);
        SurveyViewModel GetById(int id);
        List<SurveyViewModel> GetAll();
        List<StatisticsViewModel> GetAllStatistics();
    }
}
