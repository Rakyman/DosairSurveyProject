﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Template.BusinessLogic.RepositoryBusiness.ApplicationBusiness.Abstract;
using Template.Data.DataModels.ApplicationModels;
using Template.Model.ViewModels.ApplicationViewModel;
using Template.Service.Concrete;

namespace Template.BusinessLogic.RepositoryBusiness.ApplicationBusiness.Concrete
{
   public class SurveyBusiness:ISurveyBusiness
    {
       //inserts a survey ino the database
       public void Insert(SurveyViewModel model)
       {
           using (var db=new SurveyRepository())
           {
               //checks first if a participants is eligible to  take part in the survey
               if (!UserDataValid(model.ParticipantId)) return;
               db.Insert(ConvertToSurvey(model));
           }
       }

       //updates a survey
       public void Update(SurveyViewModel model)
       {
           using (var db = new SurveyRepository())
           {
               var obj = GetById(model.Id);

               //items to be updated
               obj.Date = model.Date;
               obj.ParticipantId = model.ParticipantId;
               obj.QuestionId = model.QuestionId;

               db.Update(ConvertToSurvey(obj));
           }
       }


       //determines whether a participant has taken part in a survey or not
       public bool ParticipantFilledSurvey(string username)
       {
           return GetAll().Exists(x => x.ParticipantId.ToLower().Equals(username.ToLower()));
       }

       //determines if users has filled in all the survey questions or not
       private bool UserDataValid(string username)
       {
           var quebus = new QuestionBusiness();
           //total number of questions
           var numq = quebus.GetAll().Count;
           //total number of participants question in the survey table
           var userresp = GetAll().Count(x => x.ParticipantId.ToLower().Equals(username.ToLower()));
           //determining the results
           return userresp < numq;
       }

       //gets a survey based on its id
       public SurveyViewModel GetById(int id)
       {
           using (var db = new SurveyRepository())
           {
               var obj = db.GetById(id);
               return ConvertToSurveyViewModel(obj);
           }
       }

       //gets all surveys
       public List<SurveyViewModel> GetAll()
       {
           using (var db = new SurveyRepository())
           {
               return db.GetAll().Select(ConvertToSurveyViewModel).ToList();
           }
       }

       //gets all statistics for each question
       public List<StatisticsViewModel> GetAllStatistics()
       {
           var questionBusiness = new QuestionBusiness();

           return questionBusiness.GetAll().Select(q => new StatisticsViewModel
           {
               Quesdesc = q.Description,
               //counts total number of apple votes in the database based on a question id
               NumAppleVotes = CountVotes(q.Id, "Apple"),
               //counts total number of android votes in the database based on a question id
               NumAndroidVotes = CountVotes(q.Id, "Android"),
               //counts total number of votes based on a question id
               Total = QueTotal(q.Id)
           }).ToList();
       }

       //gets all totals and computes the percentage
       public TotalsViewModel GetTotals()
       {
           var totals = new TotalsViewModel
           {
               //determines the number of people who have participated in the survey
               NumResp = TotNumRespones(),
               //counts the total number of registered participants
               NumPart = TotNumPart(),
               //calculates the percentage of the apple  votes
               ApplePerc = ApplePerc().ToString("0.00")+"%",
               //calculates the percentage of the androis  votes
               AndroidPerc = AndroidPerc().ToString("0.00")+"%",
               //counts the total number of android votes
               NumAndroidVotes= TotNumAndroidVotes(),
               //counts the total number of apple votes
               NumAppleVotes= TotNumAppleVotes(),
               //counts the total number of votes casted
               NumTotVotes=TotNumVotes()
           };

           return totals;
       }


       //method to count the total number of apple votes
       private int TotNumAppleVotes()
       {
           var totApple = GetAll().Count(x => x.SelectedOption.ToLower().Equals("apple"));
           return totApple;
       }
       //method to count the total number of android votes
       private int TotNumAndroidVotes()
       {
           var totAndroid = GetAll().Count(x => x.SelectedOption.ToLower().Equals("android"));
           return totAndroid;
       }
       //method to count the total number of votes
       private int TotNumVotes()
       {
           return GetAll().Count;
       }

       //method to count the total number of people who participated in the survey
       private  int TotNumRespones()
       {
           return GetAll().Select(x => x.ParticipantId).Distinct().Count();
       }

       //method to count the total number of people registered to participate in the survey
       private static int TotNumPart()
       {
           var partBus = new ParticipationBusiness();
           return partBus.GetAll().Select(x => x.Id).Distinct().Count();
       }

       //method to calculate the percentage of android votes
       private  double AndroidPerc()
       {
           var totcount = GetAll().Count;
           var totAndroid = TotNumAndroidVotes();
           var perc = ((double)totAndroid / totcount * 100);
           return perc;
       }
       //method to calculate the percentage of apple votes
       private double ApplePerc()
       {
           var totcount = GetAll().Count;
           var totApple = TotNumAppleVotes();
           var perc = ((double)totApple / totcount) * 100;
           
           return perc;
       }
       //method to count number of votes based on either android or apple and the question id
       private int CountVotes(int queid, string selectedvalue)
       {
           var count =
               GetAll().Count(m => m.QuestionId == queid && m.SelectedOption.ToLower().Equals(selectedvalue.ToLower()));
           return count;
       }

       //counts total number of votes for a specific question
       private int QueTotal(int queid)
       {
           var count =
               GetAll().Count(m => m.QuestionId == queid);
           return count;
       }

       private static Survey ConvertToSurvey(SurveyViewModel model)
       {
           return new Survey
           {
               Date=model.Date,
               Id=model.Id,
               ParticipantId=model.ParticipantId,
               QuestionId =model.QuestionId,
               SelectedOption=model.SelectedOption
           };
       }

       private static SurveyViewModel ConvertToSurveyViewModel(Survey model)
       {
           return new SurveyViewModel
           {
               Date = model.Date,
               Id = model.Id,
               ParticipantId = model.ParticipantId,
               QuestionId = model.QuestionId,
               SelectedOption=model.SelectedOption
           };
       }
    }
}
