﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Template.BusinessLogic.RepositoryBusiness.ApplicationBusiness.Abstract;
using Template.Data.DataModels.ApplicationModels;
using Template.Model.ViewModels.ApplicationViewModel;
using Template.Service.Concrete;

namespace Template.BusinessLogic.RepositoryBusiness.ApplicationBusiness.Concrete
{
    public class ParticipationBusiness:IParticipationBusiness
    {
       
        //this method saves an object into the database
        public void Insert(ParticipationViewModel model)
        {
            using (var db=new ParticipantRepository())
            {
                db.Insert(ConvertToParticipant(model));
            }
        }

        //gets all participants who have not yet participated in the survey
        public List<ParticipationViewModel> GetAllElibleParticpants()
        {
            var surveyBusiness = new SurveyBusiness();
            return GetAll().Where(x => !surveyBusiness.ParticipantFilledSurvey(x.Id)).ToList();
        }

        //updates a participants details
        public void Update(ParticipationViewModel model)
        {
            using (var db = new ParticipantRepository())
            {
                db.Update(ConvertToParticipant(model));
            }
        }

        public bool ParticipantExist(string id)
        {
            return GetAll().Any(x => x.Id.ToLower().Equals(id.ToLower()));
        }

        //gets a partcipant based on their id
        public ParticipationViewModel GetById(string id)
        {
            using (var db = new ParticipantRepository())
            {
                var obj = db.GetAll().First(x => x.Id.ToLower().Equals(id.ToLower()));
                return ConvertToParticipantViewModel(obj);
            }
        }

        //gets all participants from the database 
        public List<ParticipationViewModel> GetAll()
        {
            using (var db = new ParticipantRepository())
            {
                return db.GetAll().Select(ConvertToParticipantViewModel).ToList();
            }
        }

        //converts a participantviewmodel to participant 
        private static Participant ConvertToParticipant(ParticipationViewModel model)
        {
            return new Participant
            {
                CellNumber = model.CellNumber,
                EmailAddress = model.EmailAddress,
                FirstName = model.FirstName,
                LastName = model.LastName,
                Id = model.Id
            };
        }

        private static ParticipationViewModel ConvertToParticipantViewModel(Participant model)
        {
            return new ParticipationViewModel
            {
                CellNumber = model.CellNumber,
                EmailAddress = model.EmailAddress,
                FirstName = model.FirstName,
                LastName = model.LastName,
                Id = model.Id
            };
        }
    }
}
