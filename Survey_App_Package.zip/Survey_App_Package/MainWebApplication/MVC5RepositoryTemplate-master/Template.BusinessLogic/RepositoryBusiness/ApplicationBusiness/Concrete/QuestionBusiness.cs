﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Template.BusinessLogic.RepositoryBusiness.ApplicationBusiness.Abstract;
using Template.Data.DataModels.ApplicationModels;
using Template.Model.ViewModels.ApplicationViewModel;
using Template.Service.Concrete;


namespace Template.BusinessLogic.RepositoryBusiness.ApplicationBusiness.Concrete
{
    public class QuestionBusiness:IQuestionBusiness
    {
        //inserts a qustion in the database
        public void Insert(QuestionViewModel model)
        {
            using (var db=new QuestionRepository())
            {
                db.Insert(ConvertToQuestion(model));
            }
        }

        public void Update(QuestionViewModel model)
        {
            using (var db = new QuestionRepository())
            {
                //geting an object based on its id
                var obj = GetById(model.Id);

                //updating the description of an object
                obj.Description = model.Description;

                //saving the updates to the database
                db.Update(ConvertToQuestion(obj));
            }
        }

        //gets a question based on its id
        public QuestionViewModel GetById(int id)
        {
            using (var db = new QuestionRepository())
            {
                //geting an object based on its id
                var obj = db.GetById(id);
                //converting an object of question data type to questionviewmodel data type
                return ConvertToQuestionViewModel(obj);
            }
        }

        //gets all the questions
        public List<QuestionViewModel> GetAll()
        {
            using (var db = new QuestionRepository())
            {
                return db.GetAll().Select(ConvertToQuestionViewModel).ToList();
            }
        }

        private static Question ConvertToQuestion(QuestionViewModel model)
        {
            return new Question
            {
                Description = model.Description,
                Id = model.Id
            };
        }

        private static QuestionViewModel ConvertToQuestionViewModel(Question model)
        {
            return new QuestionViewModel
            {
                Description = model.Description,
                Id = model.Id
            };
        }
    }
}
