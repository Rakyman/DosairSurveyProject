﻿using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using Template.Data.Connection;
using Template.Data.DataModels.AccountModels;

namespace Template.BusinessLogic.RepositoryBusiness.AccountBusiness.Concrete
{
    public class RoleBusiness
    {
        private RoleManager<ApplicationRole> RoleManager { get; set; }

        public RoleBusiness()
        {
           
            RoleManager = new RoleManager<ApplicationRole>(new RoleStore<ApplicationRole>(new DataContext()));
        }

        public bool RoleExists(string name)
        {
            return RoleManager.RoleExists(name);
        }

        public bool CreateRole(string name)
        {
            var idResult = RoleManager.Create(new ApplicationRole(name));
            return idResult.Succeeded;
        }

      
    }
}
