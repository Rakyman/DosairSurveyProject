﻿using System.Collections.Generic;
using Template.Data.DataModels.ApplicationModels;
using Template.Model.ViewModels.ApplicationViewModel;
using Template.Service.Concrete;

namespace Template.BusinessLogic.RepositoryBusiness.AccountBusiness.Concrete
{
    public class QuestionsInitialize
    {
        //list of questions to be used in the survey
        private static IEnumerable<QuestionViewModel> MySurveyQuestions()
        {
            //list containing the quetions
            var mylist = new List<QuestionViewModel>
            {
                new QuestionViewModel {Description = "Which one of the two do you think is ideal for you?"},
                new QuestionViewModel {Description = "Which of the two is more stable and provides ease of use?"},
                new QuestionViewModel {Description = "Which device has more storage space?"},
                new QuestionViewModel {Description = "Which device is more secure?"},
                new QuestionViewModel {Description = "Which of the two has a longer battery and life span?"},
                new QuestionViewModel {Description = "Which device offers a greater number of useful apps especially for students?"},
                new QuestionViewModel {Description = "which of the two has more applications  for download on the google/app store?"},
                 new QuestionViewModel {Description = "Which device would your recommend for students?"},
            };

            return mylist;
        }

        //method that loads the questions into the database when the application is first run
        public static void Intialize()
        {
            using (var db=new QuestionRepository())
            {
                //checking the database first if the questions exits
                if (db.GetAll().Count > 0) return;

                //inserting each question in the list into the database
                foreach (var q in MySurveyQuestions())
                {
                    db.Insert(new Question{Description=q.Description,Id=q.Id});
                }
            }
        }
    }
}
