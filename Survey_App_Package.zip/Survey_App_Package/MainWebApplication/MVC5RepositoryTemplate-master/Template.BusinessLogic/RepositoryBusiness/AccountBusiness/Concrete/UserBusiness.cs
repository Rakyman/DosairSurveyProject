﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Template.Data.DataModels.AccountModels;
using Template.Model;
using Template.Service.Concrete;

namespace Template.BusinessLogic.RepositoryBusiness.AccountBusiness.Concrete
{
   public class UserBusiness
    {
       //adds a usser into the database
       public void AddUser(RegisterModel model)
       {
           using (var db=new UserAccountRepository())
           {
               db.Insert(new UserAccount
               {
                   Password=model.Password,
                   Username=model.UserName,
                   Role=model.Role
               });
           }
       }

       //gets the user password based on the username
       public string GetPassword(string username)
       {
           return username.ToLower().Equals("appadmin") ? "Password" : GetAll().First(x => x.UserName.ToLower().Equals(username.ToLower())).Password;
       }

       //gets a user base on their username and passowrd
       public RegisterModel GetUser(string username,string password)
       {
           return
               GetAll(
                       ).First(x => x.UserName.ToLower().Equals(username.ToLower()) &&
                           x.Password.ToLower().Equals(password.ToLower()));
       }
       //gets all users
       public List<RegisterModel> GetAll()
       {
           using (var db = new UserAccountRepository())
           {
               return db.GetAll().Select(model=>new RegisterModel{Password=model.Password,UserName=model.Username,Role=model.Role}).ToList();
           }
       }
    }
}
