﻿using System.Data.Entity;
using Template.Data.Connection;

namespace Template.BusinessLogic.RepositoryBusiness.AccountBusiness.Concrete
{
    public  static class InitializeBusiness
    {
        public static void Initilize()
        {
            Database.SetInitializer<DataContext>(new DbInitialize<DataContext>());
            var ctx = new DataContext();
          //ctx.Database.CreateIfNotExists();
            ctx.Database.Initialize(true);
        }

    }
}
