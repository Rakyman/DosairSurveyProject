﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Mail;
using Template.Data.DataModels.ApplicationModels;
using Template.Model.ViewModels.ApplicationViewModel;

namespace Template.BusinessLogic.Communication
{
    public class Email
    {
        public MailAddress To { get; set; }
        public MailAddress From { get; set; }
        public string Attach { get; set; }
        public string Sub { get; set; }
        public string Body { get; set; }
       


        public string SendMail(EmailContent model)
        {
            var m = new MailMessage
            {
                Subject = "Login Credentials",
                Body =model.Message,
                IsBodyHtml = true,
                From = new MailAddress("21217040@dut4life.ac.za", "MyNSFAS-Administrators")
            };
            m.Sender = m.From;
  
             To = new MailAddress(model.To);
             m.To.Add(To);
               
            var smtp = new SmtpClient
            {
                Host = "pod51014.outlook.com",
                Credentials = new NetworkCredential("21217040@dut4life.ac.za", "Dut921208"),
                EnableSsl = true,
                Port = 587
            };

            try
            {
                smtp.Send(m);
                return "Email successfully sent";
            }
            catch (Exception)
            {
                return "Email not sent";
            }
        }
    }
}
