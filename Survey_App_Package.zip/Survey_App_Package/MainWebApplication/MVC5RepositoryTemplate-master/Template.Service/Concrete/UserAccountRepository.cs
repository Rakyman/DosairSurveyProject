﻿using System;
using System.Collections.Generic;
using System.Linq;
using Template.Data;
using Template.Data.Connection;
using Template.Data.DataModels.AccountModels;
using Template.Data.GenericRepository;
using Template.Service.Abstract;

namespace Template.Service.Concrete
{
    public class UserAccountRepository : IUserAccountRepository
    {
        private DataContext _datacontext = null;
        private readonly IRepository<UserAccount> _userRepository;

        public UserAccountRepository()
        {
            _datacontext = new DataContext();
            _userRepository = new RepositoryService<UserAccount>(_datacontext);
            
        }

        public UserAccount GetById(int id)
        {
           return _userRepository.GetById(id);
        }

        public List<UserAccount> GetAll()
        {
            return _userRepository.GetAll().ToList();
        }

        public void Insert(UserAccount model)
        {
            _userRepository.Insert(model);
        }

        public void Update(UserAccount model)
        {
            _userRepository.Update(model);
        }

        public void Delete(UserAccount model)
        {
            _userRepository.Delete(model);
        }

        public IEnumerable<UserAccount> Find(Func<UserAccount, bool> predicate)
        {
           return _userRepository.Find(predicate).ToList();
        }

        public void Dispose()
        {
            _datacontext.Dispose();
            _datacontext = null;
        }
    }
}
