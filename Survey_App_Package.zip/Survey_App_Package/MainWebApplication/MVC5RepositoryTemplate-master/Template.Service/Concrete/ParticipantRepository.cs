﻿using System;
using System.Collections.Generic;
using System.Linq;
using Template.Data;
using Template.Data.Connection;
using Template.Data.DataModels.ApplicationModels;
using Template.Data.GenericRepository;
using Template.Service.Abstract;

namespace Template.Service.Concrete
{
    public class ParticipantRepository:IParticipantRepository
    {
        private DataContext _datacontext = null;
        private readonly IRepository<Participant> _participantRepository;

        public ParticipantRepository()
        {
            _datacontext = new DataContext();
            _participantRepository = new RepositoryService<Participant>(_datacontext);
            
        }

        public Participant GetById(int id)
        {
           return _participantRepository.GetById(id);
        }

        public List<Participant> GetAll()
        {
            return _participantRepository.GetAll().ToList();
        }

        public void Insert(Participant model)
        {
            _participantRepository.Insert(model);
        }

        public void Update(Participant model)
        {
            _participantRepository.Update(model);
        }

        public void Delete(Participant model)
        {
            _participantRepository.Delete(model);
        }

        public IEnumerable<Participant> Find(Func<Participant, bool> predicate)
        {
           return _participantRepository.Find(predicate).ToList();
        }

        public void Dispose()
        {
            _datacontext.Dispose();
            _datacontext = null;
        }
    }
}
