﻿using System;
using System.Collections.Generic;
using System.Linq;
using Template.Data;
using Template.Data.Connection;
using Template.Data.DataModels.ApplicationModels;
using Template.Data.GenericRepository;
using Template.Service.Abstract;

namespace Template.Service.Concrete
{
    public class SurveyRepository:ISurveyRepository
    {
        private DataContext _datacontext = null;
        private readonly IRepository<Survey> _surveyRepository;

        public SurveyRepository()
        {
            _datacontext = new DataContext();
            _surveyRepository = new RepositoryService<Survey>(_datacontext);
            
        }

        public Survey GetById(int id)
        {
           return _surveyRepository.GetById(id);
        }

        public List<Survey> GetAll()
        {
            return _surveyRepository.GetAll().ToList();
        }

        public void Insert(Survey model)
        {
            _surveyRepository.Insert(model);
        }

        public void Update(Survey model)
        {
            _surveyRepository.Update(model);
        }

        public void Delete(Survey model)
        {
            _surveyRepository.Delete(model);
        }

        public IEnumerable<Survey> Find(Func<Survey, bool> predicate)
        {
           return _surveyRepository.Find(predicate).ToList();
        }

        public void Dispose()
        {
            _datacontext.Dispose();
            _datacontext = null;
        }
    }
}
