﻿using System;
using System.Collections.Generic;
using System.Linq;
using Template.Data;
using Template.Data.Connection;
using Template.Data.DataModels.ApplicationModels;
using Template.Data.GenericRepository;
using Template.Service.Abstract;

namespace Template.Service.Concrete
{
    public class QuestionRepository:IQuestionRepository
    {
        private DataContext _datacontext = null;
        private readonly IRepository<Question> _questionRepository;

        public QuestionRepository()
        {
            _datacontext = new DataContext();
            _questionRepository = new RepositoryService<Question>(_datacontext);
            
        }

        public Question GetById(int id)
        {
           return _questionRepository.GetById(id);
        }

        public List<Question> GetAll()
        {
            return _questionRepository.GetAll().ToList();
        }

        public void Insert(Question model)
        {
            _questionRepository.Insert(model);
        }

        public void Update(Question model)
        {
            _questionRepository.Update(model);
        }

        public void Delete(Question model)
        {
            _questionRepository.Delete(model);
        }

        public IEnumerable<Question> Find(Func<Question, bool> predicate)
        {
           return _questionRepository.Find(predicate).ToList();
        }

        public void Dispose()
        {
            _datacontext.Dispose();
            _datacontext = null;
        }
    }
}
