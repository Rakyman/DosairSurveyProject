﻿using System;
using System.Collections.Generic;
using Template.Data;
using Template.Data.DataModels.AccountModels;

namespace Template.Service.Abstract
{
    public interface IUserAccountRepository: IDisposable
    {
        UserAccount GetById(Int32 id);
        List<UserAccount> GetAll();
        void Insert(UserAccount model);
        void Update(UserAccount model);
        void Delete(UserAccount model);
        IEnumerable<UserAccount> Find(Func<UserAccount, bool> predicate);   

    }
}
