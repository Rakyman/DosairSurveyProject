﻿using System;
using System.Collections.Generic;
using Template.Data;
using Template.Data.DataModels.ApplicationModels;

namespace Template.Service.Abstract
{
    public interface ISurveyRepository : IDisposable
    {
        Survey GetById(Int32 id);
        List<Survey> GetAll();
        void Insert(Survey model);
        void Update(Survey model);
        void Delete(Survey model);
        IEnumerable<Survey> Find(Func<Survey, bool> predicate);   

    }
}
