﻿using System;
using System.Collections.Generic;
using Template.Data;
using Template.Data.DataModels.ApplicationModels;

namespace Template.Service.Abstract
{
    public interface IParticipantRepository : IDisposable
    {
        Participant GetById(Int32 id);
        List<Participant> GetAll();
        void Insert(Participant model);
        void Update(Participant model);
        void Delete(Participant model);
        IEnumerable<Participant> Find(Func<Participant, bool> predicate);   

    }
}
