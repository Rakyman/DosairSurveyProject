﻿using System;
using System.Collections.Generic;
using Template.Data;
using Template.Data.DataModels.ApplicationModels;

namespace Template.Service.Abstract
{
    public interface IQuestionRepository : IDisposable
    {
        Question GetById(Int32 id);
        List<Question> GetAll();
        void Insert(Question model);
        void Update(Question model);
        void Delete(Question model);
        IEnumerable<Question> Find(Func<Question, bool> predicate);   

    }
}
