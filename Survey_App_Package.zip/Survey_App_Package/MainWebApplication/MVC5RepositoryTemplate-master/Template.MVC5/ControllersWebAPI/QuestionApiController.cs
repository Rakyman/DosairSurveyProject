﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Template.BusinessLogic.RepositoryBusiness.ApplicationBusiness.Concrete;
using Template.Model.ViewModels.ApplicationViewModel;

namespace Template.MVC5.ControllersWebAPI
{
    public class QuestionApiController : ApiController
    {
        private readonly QuestionBusiness _questionBusiness;

        public QuestionApiController()
        {
            this._questionBusiness = new QuestionBusiness();
        }

        // GET: api/QuestionApi
        public IEnumerable<QuestionViewModel> Get()
        {
            return _questionBusiness.GetAll();
        }

       
        // POST: api/QuestionApi
        public void Post([FromBody]QuestionViewModel model)
        {
            _questionBusiness.Insert(model);
        }

    }
}
