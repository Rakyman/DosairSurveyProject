﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Template.BusinessLogic.RepositoryBusiness.ApplicationBusiness.Concrete;
using Template.Model.ViewModels.ApplicationViewModel;

namespace Template.MVC5.ControllersWebAPI
{
    public class ParticipantApiController : ApiController
    {
        private readonly ParticipationBusiness _participationBusiness;

        public ParticipantApiController()
        {
            this._participationBusiness = new ParticipationBusiness();
        }

        // GET: api/ParticipantApi
        public IEnumerable<ParticipationViewModel> Get()
        {
            return _participationBusiness.GetAll();
        }

        

        // POST: api/ParticipantApi
        public void Post([FromBody]ParticipationViewModel model)
        {
            _participationBusiness.Insert(model);
        }

    }
}
