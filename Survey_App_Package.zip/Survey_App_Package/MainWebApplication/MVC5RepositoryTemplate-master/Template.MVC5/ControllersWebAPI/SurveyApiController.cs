﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Template.BusinessLogic.RepositoryBusiness.ApplicationBusiness.Concrete;
using Template.Model.ViewModels.ApplicationViewModel;

namespace Template.MVC5.ControllersWebAPI
{
    public class SurveyApiController : ApiController
    {

        private readonly SurveyBusiness _surveyBusiness;

        public SurveyApiController()
        {
            this._surveyBusiness = new SurveyBusiness();
        }

        // GET: api/SurveyApi
        public IEnumerable<SurveyViewModel> Get()
        {
            return _surveyBusiness.GetAll();
        }

        // POST: api/SurveyApi
        public void Post([FromBody]SurveyViewModel model)
        {
            _surveyBusiness.Insert(model);
        }

    }
}
