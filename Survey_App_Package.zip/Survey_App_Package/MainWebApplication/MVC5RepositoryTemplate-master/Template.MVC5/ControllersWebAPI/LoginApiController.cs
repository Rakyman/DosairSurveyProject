﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Template.BusinessLogic.RepositoryBusiness.AccountBusiness.Concrete;
using Template.Model;

namespace Template.MVC5.ControllersWebAPI
{
    public class LoginApiController : ApiController
    {
        private readonly UserBusiness _user;

        public LoginApiController()
        {
            _user = new UserBusiness();
        }

        // GET: api/LoginApi
        public RegisterModel Get(string username,string password)
        {
           
            return _user.GetUser(username, password);
        }

        // GET: api/LoginApi
        public List<RegisterModel> Get()
        {
            return _user.GetAll();
        }

       
    }
}
