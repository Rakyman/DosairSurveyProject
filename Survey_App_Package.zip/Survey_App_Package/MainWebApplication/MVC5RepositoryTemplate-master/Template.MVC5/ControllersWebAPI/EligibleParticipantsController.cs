﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Template.BusinessLogic.RepositoryBusiness.ApplicationBusiness.Concrete;
using Template.Model.ViewModels.ApplicationViewModel;

namespace Template.MVC5.ControllersWebAPI
{
    public class EligibleParticipantsController : ApiController
    {
        // GET: api/EligibleParticipants
        public IEnumerable<ParticipationViewModel> Get()
        {
            var participationBusiness = new ParticipationBusiness();
            return participationBusiness.GetAllElibleParticpants();
        }

    }
}
