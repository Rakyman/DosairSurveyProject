﻿using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using Microsoft.Owin.Security;
using Template.BusinessLogic.RepositoryBusiness.AccountBusiness.Concrete;
using Template.BusinessLogic.RepositoryBusiness.ApplicationBusiness.Concrete;
using Template.Model;
using Template.Model.ViewModels.AccountViewModel;

namespace Template.MVC5.Controllers
{
   
    public class LoginController : Controller
    {

        private IAuthenticationManager AuthenticationManager
        {
            get
            {
                return HttpContext.GetOwinContext().Authentication;
            }
        }

        // GET: Login
        [AllowAnonymous]
        public ActionResult Index()
        {
            var loginview = new LoginModel();
            return View(loginview);
        }

        [ValidateAntiForgeryToken]
        [HttpPost]
        [AllowAnonymous]
        public async Task<ActionResult> Index(LoginModel model, string returnUrl)
        {
            if (!ModelState.IsValid)
            {
                ModelState.AddModelError("", "Invalid username or password.");
                return View(model);
            }
               

            var loginbusiness = new LoginBusiness();
            var survbuss = new SurveyBusiness();
            var regbusines = new RegisterBusiness();
           

            var result = await loginbusiness.LogUserIn(model, AuthenticationManager);

            if (result)
            {

                if (model.UserName.ToLower().Equals("appadmin"))
                {
                    return RedirectToAction("AppAdmin", "Layout");
                }

                if (regbusines.UserInRole(model.UserName, "AppUser"))
                {
                    return RedirectToAction(survbuss.ParticipantFilledSurvey(getid(model.UserName)) ? "EligibleParticipant" : "OverView", "Survey");
                }
            }
          
            ModelState.AddModelError("", "Invalid username or password.");
            return View(model);
        }

        //
        // POST: /Account/LogOff
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult LogOff()
        {
            AuthenticationManager.SignOut();
            return RedirectToAction("Index", "Login");
        }

        private string getid(string username)
        {
            return
                new ParticipationBusiness().GetAll().First(x => x.EmailAddress.ToLower().Equals(username.ToLower())).Id;
        }

        private ActionResult RedirectToLocal(string returnUrl)
        {
            if (Url.IsLocalUrl(returnUrl))
            {
                return Redirect(returnUrl);
            }
            return RedirectToAction("Index", "Login");
        }




      




       
    }
}