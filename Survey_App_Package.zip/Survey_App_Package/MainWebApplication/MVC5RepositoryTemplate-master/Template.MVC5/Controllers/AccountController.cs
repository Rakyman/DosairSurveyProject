﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Template.BusinessLogic.Communication;
using Template.BusinessLogic.RepositoryBusiness.AccountBusiness.Concrete;
using Template.Model;
using Template.Model.ViewModels.ApplicationViewModel;

namespace Template.MVC5.Controllers
{
    public class AccountController : Controller
    {
        // GET: Account
        public ActionResult Index()
        {
            return View(new RegisterModel());
        }

        [HttpPost]
        public ActionResult Index(RegisterModel model)
        {
            try
            {
                var user = new UserBusiness();
                var email = new Email();

                var password = user.GetPassword(model.UserName);
                var msg = "Good Day,your password is " + password;

                email.SendMail(new EmailContent {Message = msg, To = model.UserName});

                return RedirectToAction("Message");
            }
            catch
            {
                return View(model);
            }
        }

        public ActionResult Message()
        {
            return View();
            
        }
    }
}