﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Template.BusinessLogic.RepositoryBusiness.ApplicationBusiness.Concrete;

namespace Template.MVC5.Controllers
{
      [Authorize(Roles = "AppAdmin")]
    public class QuestionController : Controller
    {
        private readonly QuestionBusiness _queBuss;

        public QuestionController()
        {
            _queBuss = new QuestionBusiness();
        }

        // GET: Question
          [Authorize(Roles = "AppAdmin")]
          public ActionResult Index()
          {
              return View(_queBuss.GetAll());
          }


    }
}
