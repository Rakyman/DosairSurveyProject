﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Template.BusinessLogic.RepositoryBusiness.ApplicationBusiness.Concrete;

namespace Template.MVC5.Controllers
{
      [Authorize(Roles = "AppAdmin")]
    public class ParticipantController : Controller
    {
          [Authorize(Roles = "AppAdmin")]
        public ActionResult Index()
        {
            var partBus=new ParticipationBusiness();
            return View(partBus.GetAll());
        }
    }
}