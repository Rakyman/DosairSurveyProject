﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Helpers;
using System.Web.Mvc;
using System.Web.Security;
using Template.BusinessLogic.RepositoryBusiness.ApplicationBusiness.Concrete;
using Template.Model.ViewModels.ApplicationViewModel;
using Template.MVC5.Helpers;

namespace Template.MVC5.Controllers
{
    [Authorize]
    public class LayoutController : Controller
    {
        private readonly SurveyBusiness _surveyBusiness;

        public LayoutController()
        {
            _surveyBusiness = new SurveyBusiness();
        }

        // GET: Layout
        [Authorize(Roles="AppAdmin")]
        public ActionResult AppAdmin()
        {
            return View(_surveyBusiness.GetTotals());
        }

       
    }
}