﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Helpers;
using System.Web.Mvc;
using System.Web.UI;
using System.Web.UI.WebControls;
using Template.BusinessLogic.RepositoryBusiness.ApplicationBusiness.Concrete;
using Template.Model.ViewModels.ApplicationViewModel;
using Template.MVC5.Helpers;

namespace Template.MVC5.Controllers
{
     [Authorize(Roles = "AppAdmin")]
    public class SurveyReportController : Controller
    {
        private readonly SurveyBusiness _surveyBusiness;

        public SurveyReportController()
        {
            this._surveyBusiness = new SurveyBusiness();
        }

       
           [Authorize(Roles = "AppAdmin")]
        public ActionResult AllStatistics(int? page)
        {
            var pageNumber = (page ?? 1);
            Session.Remove("Message");
            ViewBag.Message = Session["Message"];
            return View(_surveyBusiness.GetAllStatistics());

        }

           [Authorize(Roles = "AppAdmin")]
        public ActionResult ExportAllStatistics(int id)
        {
            
            var t = "";
            var ty = "";

            switch (id)
            {
                case 2:
                    t = "xls";
                    ty = "excel";
                    break;
                case 3:
                    t = "doc";
                    ty = "word";
                    break;
            }
            var gv = new GridView {DataSource = _surveyBusiness.GetAllStatistics()};
            gv.DataBind();

            Response.ClearContent();
            Response.Buffer = true;
            Response.AddHeader("content-disposition", "attachment; filename=SurveyReport." + t);
            Response.ContentType = "application/ms-" + ty;
            Response.Charset = "";

            var sw = new StringWriter();
            var htw = new HtmlTextWriter(sw);

            gv.RenderControl(htw);

            Response.Output.Write(sw.ToString());
            Response.Flush();
            Response.End();

            return RedirectToAction("AllStatistics");
        }
        
    }
}