﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Microsoft.Ajax.Utilities;
using Microsoft.AspNet.Identity;
using Template.BusinessLogic.RepositoryBusiness.ApplicationBusiness.Concrete;
using Template.Model.ViewModels.ApplicationViewModel;

namespace Template.MVC5.Controllers
{
      [Authorize]
    public class SurveyController : Controller
    {
        private readonly SurveyBusiness _surveyBusiness;
        private readonly QuestionBusiness _questionBusiness;
        private readonly ParticipationBusiness _participationBusiness;
        private int _x;

        public SurveyController()
        {
            _participationBusiness = new ParticipationBusiness ();
            _questionBusiness = new QuestionBusiness();
            _surveyBusiness = new SurveyBusiness();
        }
        
          [Authorize(Roles = "AppAdmin")]
        public ActionResult Index()
        {
              //list of all statistics
            var list = _surveyBusiness.GetAllStatistics();
              //gets survey totals
            var totals = _surveyBusiness.GetTotals();
              //displays the total number of apple votes on the view
            ViewBag.AppTot = totals.NumAppleVotes;
            //displays the total number of android votes on the view
            ViewBag.AndTot = totals.NumAndroidVotes;
            //displays the total number of  votes on the view
            ViewBag.totvotes = totals.NumTotVotes;

            return View(list);
        }

           [Authorize(Roles = "AppUser")]
          public ActionResult OverView()
          {
              return View();
          }

           [Authorize(Roles = "AppUser")]
           public ActionResult EligibleParticipant()
           {
               return View();
           }

        // GET: Survey/Create
            [Authorize(Roles = "AppUser")]
        public ActionResult Create(int?y)
        {

            if (y == null)
            {
                _x = 1;
            }
            else
            {
                _x = (int) y;
            }
            TempData["val"] = _x.ToString();
            @ViewBag.qno = "Question " + _x;

                //gets a participant id based on the username
            var partid =
                _participationBusiness.GetAll()
                    .First(m => m.EmailAddress.ToLower().Equals(User.Identity.GetUserName().ToLower()))
                    .Id;
            var model = new SurveyCreateViewModel
            {
                Date = DateTime.Now,
                ParticipantId =partid,
                //gets the question description based on the quetion id 
                Questiondesc = _questionBusiness.GetById(_x).Description,
                QuestionId=_x
            };
           
            return View(model);
        }

        // POST: Survey/Create
           [Authorize(Roles = "AppUser")]
        [HttpPost]
        public ActionResult Create(SurveyCreateViewModel model, string selectedoption)
        {
            try
            {
                //gets the total number of questions
                var totques = _questionBusiness.GetAll().Count;
                //the current quetion number
                var currval = Convert.ToInt32(TempData["val"]);

                for (int i = currval;i<=totques;)
                {
                    //displays the quetion number
                    @ViewBag.qno = "Question " + _x;
                    i++;

                    var m = new SurveyViewModel
                    {
                        Date = model.Date,
                        SelectedOption = selectedoption,
                        Id = 1,
                        ParticipantId = model.ParticipantId,
                        QuestionId =currval
                    };
                    _surveyBusiness.Insert(m);

                    return i > totques ? RedirectToAction("Message") : Create(i);
                }
                
                return RedirectToAction("Message");
            }
            catch(Exception e)
            {
                ModelState.AddModelError(string.Empty,"Error:"+e.Message);
                return View(model);
            }
        }

           [Authorize(Roles = "AppUser")]
        public ActionResult Message()
        {
            return View();
        }
       
    }
}
