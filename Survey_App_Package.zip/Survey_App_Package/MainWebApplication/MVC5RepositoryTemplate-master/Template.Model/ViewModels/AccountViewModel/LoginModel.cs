﻿using System.ComponentModel.DataAnnotations;

namespace Template.Model.ViewModels.AccountViewModel
{
    public class LoginModel
    {
        [Required(ErrorMessage = "Enter your username")]
        [Display(Name = "Username")]
        public string UserName { get; set; }

        [Required(ErrorMessage = "Enter your password")]
        [DataType(DataType.Password)]
        [Display(Name = "Password")]
        public string Password { get; set; }

        [Display(Name = "Remember me?")]
        public bool RememberMe { get; set; }
        public string Role { get; set; }

    }
}