﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Template.Model.ViewModels.ApplicationViewModel
{
    public class TotalsViewModel
    {
        public int NumPart { get; set; }
        public int NumAndroidVotes { get; set; }
        public int NumAppleVotes { get; set; }
        public int NumTotVotes { get; set; }
        public int NumResp { get; set; }
        public string AndroidPerc { get; set; }
        public string ApplePerc { get; set; }
    }
}
