﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Template.Model.ViewModels.ApplicationViewModel
{
    public class ParticipationViewModel
    {
        [Key]
        [Display(Name="ID/Passport Number:")]
        [Required(ErrorMessage ="please enter  ID/Passport number")]
        public string Id { get; set; }
        [Display(Name = "First Name:")]
        [Required(ErrorMessage = "please enter first name")]
        public string FirstName { get; set; }
        [Display(Name = "Last Name:")]
        [Required(ErrorMessage = "please enter last name")]
        public string LastName { get; set; }
        [Display(Name = "Cell Number:")]
        [Required(ErrorMessage = "please enter cell number")]
        public string CellNumber { get; set; }
        [Display(Name = "Email Address:")]
        [DataType(DataType.EmailAddress)]
        [Required(ErrorMessage = "please enter email address")]
        public string EmailAddress { get; set; }
    }
}
