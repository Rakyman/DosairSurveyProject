﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Template.Model.ViewModels.ApplicationViewModel
{
   public class SurveyCreateViewModel
    {
        public int Id { get; set; }
        public bool SelectedOption { get; set; }
        public int QuestionId { get; set; }
        public string Questiondesc { get; set; }
        public string ParticipantId { get; set; }
        public DateTime Date { get; set; }
      
    }
}
