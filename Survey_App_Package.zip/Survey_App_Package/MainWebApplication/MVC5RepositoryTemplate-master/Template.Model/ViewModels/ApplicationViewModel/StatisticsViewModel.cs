﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Template.Model.ViewModels.ApplicationViewModel
{
   public class StatisticsViewModel
    {
       [Display(Name="Question Description:")]
       public string Quesdesc { get; set; }
       [Display(Name ="Android Votes:")]
       public int NumAndroidVotes { get; set; }
       [Display(Name = "Apple Votes:")]
       public int NumAppleVotes { get; set; }
       [Display(Name = "Total Votes:")]
       public int Total { get; set; }
    }
}
