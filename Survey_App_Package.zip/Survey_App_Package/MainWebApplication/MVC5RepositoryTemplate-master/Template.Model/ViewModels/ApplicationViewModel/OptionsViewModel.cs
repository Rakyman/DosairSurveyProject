﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Template.Model.ViewModels.ApplicationViewModel
{
    public class OptionsViewModel
    {
        public int Opt1 { get; set; }
        public int Opt2 { get; set; }
    }
}
