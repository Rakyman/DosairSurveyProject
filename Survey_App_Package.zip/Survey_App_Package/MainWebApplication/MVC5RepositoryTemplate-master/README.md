# MVC5RepositoryTemplate
An MVC 5 template that implments the repository pattern and ASP.NET identity.
The template includes bootstrap and a basic example of how to use the pattern.

Updates in this release

1) Used one context object
2) Implemented Roles
3) Updated to MVC 5
4) Updated various references
