﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Template.Test
{
    [TestClass]
    public class TestPercentage
    {
        //testing method to calculate percentage
        [TestMethod]
        public void TestMethod()
        {
            const int tot = 10;
            const int totr = 5;

            var m=new MethodsToTest();

            var result = m.BluePerc(tot, totr);

            Assert.AreEqual(50.0,result);
        }

        
    }
}
