﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Template.Test
{
    public class MethodsToTest
    {
        //the method to calculate percentage
        public double BluePerc(int totcount, int totr)
        {
            var perc =((double) totr/totcount)*100;
            return perc;
        }
    }
}
