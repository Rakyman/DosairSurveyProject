﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using Newtonsoft.Json;
using SurveyApp.BusinessLogic;
using SurveyApp.Communication;
using SurveyApp.Models;

namespace SurveyApp.Views
{
    public partial class QuestionView : PhoneApplicationPage
    {
        private int _queNo = 1;
        private readonly QuestionBusiness _q = new QuestionBusiness();
        private readonly string _user = GlobalClass.Username;

        public QuestionView()
        {
            InitializeComponent();
           
            InitQuestions(1);
        }

        private void InitQuestions(int x)
        {
            TbQueNo.Text = "Question " + x;
            TbQue.Text = _q.GetQuestion(x).Description;
        }

        private  void BtNext_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var count = _q.GetAll().Count;
               
                if (GlobalClass.OpMode == 0)
                {
                    SaveLocal();
                }
                else
                {
                    var conn = ConnectToMainApplication.Uri;
                    var webClient = new WebClient();
                    var uri = new Uri(conn + "api/SurveyApi", UriKind.Absolute);
                    var jsonData = JsonConvert.SerializeObject(Model());

                    webClient.Headers["Content-type"] = "application/json";
                    webClient.Encoding = Encoding.UTF8;
                    webClient.UploadStringAsync(uri, "Post", jsonData);
                }
                if (_queNo == count)
                {
                    NavigationService.Navigate(new Uri("/Views/ThanksView.xaml", UriKind.Relative));
                    return;
                }
                _queNo++;
                
                InitQuestions(_queNo);
                
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:" + ex.Message);
                NavigationService.Navigate(new Uri("/Views/ThanksView.xaml", UriKind.Relative));

            }

        }

        private SurveyViewModel Model()
        {
            var selected = RdOpt1.IsChecked == true ? "Android" : "Apple";
            var model = new SurveyViewModel
            {
                Date = DateTime.Now,
                Id = 1,
                ParticipantId = _user,
                QuestionId = _queNo,
                SelectedOption = selected
            };
            return model;
        }

        private void SaveLocal()
        {
            var s = new SurveyBusiness();
            s.Insert(Model());
        }
    }
}