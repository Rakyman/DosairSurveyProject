﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Windows.Web.Http;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using Newtonsoft.Json;
using SurveyApp.BusinessLogic;
using SurveyApp.Communication;
using SurveyApp.Models;

namespace SurveyApp.Views
{
    public partial class SyncDataView : PhoneApplicationPage
    {
        public SyncDataView()
        {
            InitializeComponent();
        }

        private void BtExit_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Terminate();
        }

        private void BtnSync_Click(object sender, RoutedEventArgs e)
        {
            LoadingBar.Visibility = Visibility.Visible;
            TbOutput.Text = "please wait....";
            if (GlobalClass.OpMode == 0)
            {
                MessageBox.Show("synchronization requires internet connection");
                LoadingBar.Visibility = Visibility.Collapsed;
                TbOutput.Text = "To start the data sync please click the button below";
                return;
            }
            
            var sb = new SurveyBusiness();
            foreach (var s in sb.GetAll())
            {
                var conn = ConnectToMainApplication.Uri;
                var webClient = new WebClient();
                var uri = new Uri(conn + "api/SurveyApi", UriKind.Absolute);
                var jsonData = JsonConvert.SerializeObject(s);

                webClient.Headers["Content-type"] = "application/json";
                webClient.Encoding = Encoding.UTF8;
                webClient.UploadStringAsync(uri, "Post", jsonData);

                //sb.Delete(s);
            }
            AdminBusiness.DropDb();
            LoadPart();
            LoadUsers();


            MessageBox.Show("synchronization complete!");
            LoadingBar.Visibility = Visibility.Collapsed;
            TbOutput.Text = "To start the data sync please click the button below";
        }
        private static async void LoadUsers()
        {
            var conn = ConnectToMainApplication.Uri;
            try
            {
                using (var client = new HttpClient())
                {
                    var uri =
                        new Uri(conn + "api/LoginApi");

                    var response = await client.GetAsync(uri);


                    if (!response.IsSuccessStatusCode)
                    {
                        //MessageBox.Show("application is operating in ofline mode...");
                        // return;
                    }

                    var productJsonString = await response.Content.ReadAsStringAsync();
                    var result = JsonConvert.DeserializeObject<UserAccountViewModel[]>(productJsonString).ToList();
                    AdminBusiness.LoadUserInDb(result);
                }

            }
            catch (Exception)
            {
                // ignored
            }
        }

        private static async void LoadPart()
        {
            var conn = ConnectToMainApplication.Uri;
            try
            {
                using (var client = new HttpClient())
                {
                    var uri =
                        new Uri(conn + "api/ParticipantApi");

                    var response = await client.GetAsync(uri);


                    if (!response.IsSuccessStatusCode)
                    {
                        //MessageBox.Show("application is operating in ofline mode...");
                        // return;
                    }

                    var productJsonString = await response.Content.ReadAsStringAsync();
                    var result = JsonConvert.DeserializeObject<ParticipantViewModel[]>(productJsonString).ToList();
                    AdminBusiness.LoadParticipantsInDb(result);
                }

            }
            catch (Exception)
            {
                // ignored
            }
        }
    }
}