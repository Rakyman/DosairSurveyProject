﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;

namespace SurveyApp.Views
{
    public partial class HomeView : PhoneApplicationPage
    {
        public HomeView()
        {
            InitializeComponent();

            //text to be displayed on the survey overview screen
            TbOv.Text = "NSFAS intends on buying its students tablets.They were" +
                        " advised to either buy Android or Apple tablets(Ipads)." +
                        " To decide on which tablets to buy,a survey is being conducted."+
                        "Please give us your honest opinion.";
        }

        private void BtProceed_Click(object sender, RoutedEventArgs e)
        {
            //send the user to the questionview screen
            NavigationService.Navigate(new Uri("/Views/QuestionView.xaml", UriKind.Relative));
        }
    }
}