﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Windows.Web.Http;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using Newtonsoft.Json;
using SurveyApp.BusinessLogic;
using SurveyApp.Communication;
using SurveyApp.Models;

namespace SurveyApp.Views
{
    public partial class Menue : PhoneApplicationPage
    {
        public Menue()
        {
            InitializeComponent();
        }

        private async void BtnSurv_Click(object sender, RoutedEventArgs e)
        {
            var s = new SurveyBusiness();
            if (GlobalClass.OpMode == 0)
            {
                if (s.RecordExists(GlobalClass.Username))
                {
                    MessageBox.Show("Sorry,You already Participated in the survey");
                    return;
                }
                NavigationService.Navigate(new Uri("/Views/HomeView.xaml", UriKind.Relative));
            }
            else
            {
                var conn = ConnectToMainApplication.Uri;
                try
                {
                    using (var client = new HttpClient())
                    {
                        var uri =
                            new Uri(conn + "api/EligibleParticipants");

                        var response = await client.GetAsync(uri);

                        var productJsonString = await response.Content.ReadAsStringAsync();
                        var result = JsonConvert.DeserializeObject<ParticipantViewModel[]>(productJsonString).ToList();

                        if (result.Count==0 || !result.Any(x => x.Id.ToLower().Equals(GlobalClass.Username.ToLower())))
                        {
                            MessageBox.Show("Sorry,You already Participated in the survey");
                            return;
                        }
                        NavigationService.Navigate(new Uri("/Views/HomeView.xaml", UriKind.Relative));
                        //message
                    }

                }
                catch (Exception)
                {
                    // ignored
                }
            }
            
        }

        private void BtnSync_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/Views/SyncDataView.xaml", UriKind.Relative));
        }


        private void BtExit_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Terminate();
        }
    }
}