﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using Windows.Devices.Geolocation;
using Windows.Web.Http;
using Newtonsoft.Json;
using SurveyApp.BusinessLogic;
using SurveyApp.Communication;
using SurveyApp.Models;

namespace SurveyApp
{
    public partial class MainPage
    {
        public MainPage()
        {
            InitializeComponent();
            LoginView();
            AdminBusiness.InitialiseQuestions();
            LoadPart();
           
        }


        private void OffLineMode()
        {
            try
            {
                var account = new UserAccountBusiness();
                var pb = new ParticipantBusiness();

                if (account.ValidUser(txtuser.Text, txtpassword.Password))
                {
                    GlobalClass.Username = pb.GetParticipantId(txtuser.Text);
                    GlobalClass.OpMode = 0;
                    NavigationService.Navigate(new Uri("/Views/Menue.xaml", UriKind.Relative));
                }
                else
                {
                    MessageBox.Show("invalid username/password combination");
                    LoginView();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to login in.please retry logging in if problem persists,close and open the application again");
                LoginView();
            }
        }

        public bool ValidUser(List<UserAccountViewModel> myusers)
        {
            return
                myusers
                    .Any(
                        x =>
                            x.Username.ToLower().Equals(txtuser.Text.ToLower()) &&
                            x.Password.ToLower().Equals(txtpassword.Password.ToLower()));
        }

        private static async void LoadPart()
        {
            var conn = ConnectToMainApplication.Uri;
            try
            {
                using (var client = new HttpClient())
                {
                    var uri =
                        new Uri(conn + "api/ParticipantApi");

                    var response = await client.GetAsync(uri);


                    if (!response.IsSuccessStatusCode)
                    {
                        //MessageBox.Show("Please note that the application is running in offline mode!");
                       // return;
                    }

                    var productJsonString = await response.Content.ReadAsStringAsync();
                    var result = JsonConvert.DeserializeObject<ParticipantViewModel[]>(productJsonString).ToList();
                    AdminBusiness.LoadParticipantsInDb(result);
                }

            }
            catch (Exception)
            {
                // ignored
            }
        }

        private void LoginView()
        {
           
            LoadingBar.IsEnabled = false;
            LoadingBar.Visibility = Visibility.Collapsed;
            txtpassword.Visibility = Visibility.Visible;
            txtuser.Visibility = Visibility.Visible;
            lblName.Visibility = Visibility.Visible;
            lblPass.Text = "Enter Password";
            btnLogin.Visibility = Visibility.Visible;
        }

        private async void btnLogin_Click(object sender, RoutedEventArgs e)
        {
            var conn = ConnectToMainApplication.Uri;
            var pb = new ParticipantBusiness();

            if (txtuser.Text == "" || txtpassword.Password == "")
            {
                MessageBox.Show("Please make sure all your input are not empty");
                return;
            }
            try
            {
               

                using (var client = new HttpClient())
                {
                    var uri =
                        new Uri(conn + "api/LoginApi");

                    LoadingBar.IsEnabled = true;
                    LoadingBar.Visibility = Visibility.Visible;
                    txtpassword.Visibility = Visibility.Collapsed;
                    txtuser.Visibility = Visibility.Collapsed;
                    lblName.Visibility = Visibility.Collapsed;
                    lblPass.Text = "Please wait while loading....";
                    btnLogin.Visibility = Visibility.Collapsed;
                    var response = await client.GetAsync(uri);
                    LoadingBar.IsEnabled = false;


                    if (!response.IsSuccessStatusCode)
                    {
                        MessageBox.Show("Please note that the application is running in offline mode!");
                        OffLineMode();
                        return;
                    }
                    
                    var productJsonString = await response.Content.ReadAsStringAsync();
                    var result = JsonConvert.DeserializeObject<UserAccountViewModel[]>(productJsonString).ToList();
                  
                    AdminBusiness.LoadUserInDb(result);
                    LoadPart();

                    if (!ValidUser(result))
                    {
                        MessageBox.Show("invalid username/password combination");
                        LoginView();
                        return;
                    }

                    GlobalClass.Username = pb.GetParticipantId(txtuser.Text);
                    GlobalClass.OpMode = 1;
                    NavigationService.Navigate(new Uri("/Views/Menue.xaml", UriKind.Relative));
                }

            }
            catch (Exception)
            {
                MessageBox.Show("Please note that the application is running in offline mode!");
                OffLineMode();
            }
            
        }
    }
}