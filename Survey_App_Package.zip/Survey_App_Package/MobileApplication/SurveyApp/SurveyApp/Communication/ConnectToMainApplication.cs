﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SurveyApp.Communication
{
    public static class ConnectToMainApplication
    {
        public static string Uri = "http://localhost:55624/";
    }
}
