﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SurveyApp.Data;
using SurveyApp.Models;


namespace SurveyApp.BusinessLogic
{
    public class ParticipantBusiness:DataContext
    {
        //method to insert a participant into the database
        public void Insert(ParticipantViewModel model)
        {
            using (var db=new SurveyDBContext(Conn))
            {
                //creates the database before inserting the data
                CreateDb();
                db.Participant.InsertOnSubmit(ConvertToParticipant(model));
                db.SubmitChanges();
            }
        }

        //method to get all participants
        public List<ParticipantViewModel> GetAll()
        {
            using (var db = new SurveyDBContext(Conn))
            {
                CreateDb();
                return db.Participant.ToList().Select(ConvertToParticipantViewModel).ToList();
            }
        }

        private static Participant ConvertToParticipant(ParticipantViewModel model)
        {
            return new Participant
            {
                CellNumber = model.CellNumber,
                EmailAddress = model.EmailAddress,
                FirstName = model.FirstName,
                LastName = model.LastName,
                Id = model.Id
            };
        }

        //method to get a participant based on their id
        public string GetParticipantId(string username)
        {
            return GetAll().First(x => x.EmailAddress.ToLower().Equals(username.ToLower())).Id;
        }


        private static ParticipantViewModel ConvertToParticipantViewModel(Participant model)
        {
            return new ParticipantViewModel
            {
                CellNumber = model.CellNumber,
                EmailAddress = model.EmailAddress,
                FirstName = model.FirstName,
                LastName = model.LastName,
                Id = model.Id
            };
        }

        //method to create database
        private static void CreateDb()
        {
            using (var db = new SurveyDBContext(Conn))
            {
                if (!db.DatabaseExists())
                {
                    CreateDatabase();
                }
            }
        }
    }
}
