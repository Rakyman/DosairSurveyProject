﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SurveyApp.Models;

namespace SurveyApp.BusinessLogic
{
  public static  class AdminBusiness
    {
      //loads the questions into the database
      public static void InitialiseQuestions()
      {
          var q = new QuestionBusiness();
          q.InitializeQuestions();
      }

      //method to load users into the database
      public static void LoadUserInDb(List<UserAccountViewModel> myusers)
      {
          var ub = new UserAccountBusiness();
          foreach (var m in myusers.Where(m => !ub.GetAll().Any(x => x.Username.ToLower().Equals(m.Username.ToLower()))))
          {
              ub.Insert(m);
          }
      }

      //method to load all participants in the database
      public static void LoadParticipantsInDb(List<ParticipantViewModel> myparticipants)
      {
          var pb = new ParticipantBusiness();
          foreach (var m in myparticipants.Where(m => !pb.GetAll().Any(x => x.Id.ToLower().Equals(m.Id.ToLower()))))
          {
              pb.Insert(m);
          }
      }

      //method to drop the database
      public static void DropDb()
      {
          var u = new UserAccountBusiness();
          u.DropDb();
      }
    }
}
