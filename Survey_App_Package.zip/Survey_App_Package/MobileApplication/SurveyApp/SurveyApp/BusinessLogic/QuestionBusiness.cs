﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SurveyApp.Data;
using SurveyApp.Models;

namespace SurveyApp.BusinessLogic
{
   public class QuestionBusiness:DataContext
    {
       //inserts a question into the database
        public void Insert(QuestionViewModel model)
        {
            using (var db = new SurveyDBContext(Conn))
            {
                //creates the database incase the database does not exists
                CreateDb();
                db.Question.InsertOnSubmit(ConvertToQuestion(model));
                db.SubmitChanges();
            }
        }

       //gets a question based on its id
       public QuestionViewModel GetQuestion(int id)
       {
           return GetAll().FirstOrDefault(x => x.Id == id);
       }


       //gets all the the questions
        public List<QuestionViewModel> GetAll()
        {
            using (var db = new SurveyDBContext(Conn))
            {
                //creates the database incase the database does not exists
                CreateDb();
                return db.Question.ToList().Select(ConvertToQuestionViewModel).ToList();
            }
        }

        private static Question ConvertToQuestion(QuestionViewModel model)
        {
            return new Question
            {
               Description=model.Description,
                Id = model.Id
            };
        }

        private static QuestionViewModel ConvertToQuestionViewModel(Question model)
        {
            return new QuestionViewModel
            {
                Description = model.Description,
                Id = model.Id
            };
        }


       //method to load all the questions into the databse when the app is first loaded
       public void InitializeQuestions()
       {
           //counts the  number of all the questions
           var count = GetAll().Count;
           //if the number of questions in the data base is greater than zero questions are not inserted
           if (count>0) return;
           //inserting each quetion in the list into the database 
           foreach (var q in MySurveyQuestions())
           {
               Insert(q);
           }
       }

       //list of questions to be inserted into the database
       private static IEnumerable<QuestionViewModel> MySurveyQuestions()
       {
           var mylist = new List<QuestionViewModel>
            {
                new QuestionViewModel {Description = "Which one of the two do you think is ideal for you?"},
                new QuestionViewModel {Description = "Which of the two is more stable and provides ease of use?"},
                new QuestionViewModel {Description = "Which device has more storage space?"},
                new QuestionViewModel {Description = "Which device is more secure?"},
                new QuestionViewModel {Description = "Which of the two has a longer battery and life span?"},
                new QuestionViewModel {Description = "Which device offers a greater number of useful apps especially for students?"},
                new QuestionViewModel {Description = "which of the two has more applications  for download on the google/app store?"},
                 new QuestionViewModel {Description = "Which device would your recommend for students?"},
            };

           return mylist;
       }

       //creates the database
        private static void CreateDb()
        {
            using (var db = new SurveyDBContext(Conn))
            {
                if (!db.DatabaseExists())
                {
                    CreateDatabase();
                }
            }
        }
    }
}
