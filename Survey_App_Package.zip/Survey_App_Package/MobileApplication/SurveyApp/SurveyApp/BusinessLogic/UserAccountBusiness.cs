﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using SurveyApp.Data;
using SurveyApp.Models;

namespace SurveyApp.BusinessLogic
{
    public class UserAccountBusiness:DataContext
    {
        //method to insert a user into the database
        public void Insert(UserAccountViewModel model)
        {
            using (var db = new SurveyDBContext(Conn))
            {
                CreateDb();
                db.UserAccount.InsertOnSubmit(ConvertToUserAccount(model));
                db.SubmitChanges();
            }
        }

        //method to check if a user is valid 
        public bool ValidUser(string username,string password)
        {
            return
                GetAll()
                    .Any(
                        x =>
                            x.Username.ToLower().Equals(username.ToLower()) &&
                            x.Password.ToLower().Equals(password.ToLower()));
        }

        //gets all users
        public List<UserAccountViewModel> GetAll()
        {
            using (var db = new SurveyDBContext(Conn))
            {
                CreateDb();
                return db.UserAccount.ToList().Select(ConvertToUserAccountViewModel).ToList();
            }
        }

        private static UserAccount ConvertToUserAccount(UserAccountViewModel model)
        {
            return new UserAccount
            {
                Username=model.Username,
                Password=model.Password,
                Role=model.Role
            };
        }

        private static UserAccountViewModel ConvertToUserAccountViewModel(UserAccount model)
        {
            return new UserAccountViewModel
            {
                Username = model.Username,
                Password = model.Password,
                Role = model.Role
            };
        }

        //creates the database
        private static void CreateDb()
        {
            using (var db = new SurveyDBContext(Conn))
            {
                if (!db.DatabaseExists())
                {
                    CreateDatabase();
                }
            }
        }

        //drops the database
        public void DropDb()
        {
            using (var context = new SurveyDBContext(Conn))
            {
                if (context.DatabaseExists())
                {
                    context.DeleteDatabase();
                }
            }
        }
    }
}
