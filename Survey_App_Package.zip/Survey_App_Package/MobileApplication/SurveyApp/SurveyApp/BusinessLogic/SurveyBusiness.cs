﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.Storage;
using SurveyApp.Data;
using SurveyApp.Models;

namespace SurveyApp.BusinessLogic
{
    public class SurveyBusiness:DataContext
    {
        //inserts a survey into the database
        public void Insert(SurveyViewModel model)
        {
            using (var db = new SurveyDBContext(Conn))
            {
                //creates database before inserting a survey
                CreateDb();
                db.Survey.InsertOnSubmit(ConvertToSurvey(model));
                db.SubmitChanges();
            }
        }

        //gets all surveys from the database
        public List<SurveyViewModel> GetAll()
        {
            using (var db = new SurveyDBContext(Conn))
            {
                CreateDb();
                return db.Survey.ToList().Select(ConvertToSurveyViewModel).ToList();
            }
        }

        //method to check if a participants has participated in the survey
        public bool RecordExists(string id)
        {
            return GetAll().Any(x => x.ParticipantId.ToLower().Equals(id.ToLower()));
        }

        private static Survey ConvertToSurvey(SurveyViewModel model)
        {
            return new Survey
            {
               Id=model.Id,
               Date=model.Date,
               ParticipantId=model.ParticipantId,
               QuestionId=model.QuestionId,
               SelectedOption=model.SelectedOption
            };
        }

        private static SurveyViewModel ConvertToSurveyViewModel(Survey model)
        {
            return new SurveyViewModel
            {
                Id = model.Id,
                Date = model.Date,
                ParticipantId = model.ParticipantId,
                QuestionId = model.QuestionId,
                SelectedOption = model.SelectedOption
            };
        }

        //method to create database
        private static void CreateDb()
        {
            using (var db = new SurveyDBContext(Conn))
            {
                if (!db.DatabaseExists())
                {
                    CreateDatabase();
                }
            }
        }
    }
}
