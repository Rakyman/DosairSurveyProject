﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SurveyApp.Models
{
    public class SurveyViewModel
    {
        public int Id { get; set; }
        public int QuestionId { get; set; }
        public string ParticipantId { get; set; }
        public string SelectedOption { get; set; }
        public DateTime Date { get; set; }

    }
}
