﻿using System;

namespace SurveyApp.Models
{
    internal class GlobalClass
    {
        public static string Role = "";
        public static string Username = "";
        public static int OpMode = 1;


    }
}