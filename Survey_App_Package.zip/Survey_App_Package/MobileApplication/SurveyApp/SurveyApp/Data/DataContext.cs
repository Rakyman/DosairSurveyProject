﻿namespace SurveyApp.Data
{
    public class DataContext
    {
        protected const string Conn = "Data Source=isostore:/SurveyDB.sdf";

        protected static void CreateDatabase()
        {
            using (var context = new SurveyDBContext(Conn))
            {
                if (!context.DatabaseExists())
                {
                    context.CreateDatabase();
                }
            }
        }


    }
}